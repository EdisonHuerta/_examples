<?php

	$_SERVER['QUERY_STRING'] = '/blog';
require_once 'PHPUnit/Framework.php';

require_once 'init/init.php';

class blogTest extends PHPUnit_Framework_TestCase
{
    public function testNewArrayIsEmpty()
    {
        // Create the Array fixture.
        $fixture = array();

	$blog = new blogcontroller; 
	$_SERVER['QUERY_STRING'] = '/blog';
 
        // Assert that the size of the Array fixture is 0.
        $this->assertEquals(0, sizeof($fixture));
    }
 
    public function testArrayContainsAnElement()
    {
        // Create the Array fixture.
        $fixture = array();
 
	$_SERVER['QUERY_STRING'] = '/blog';

        // Add an element to the Array fixture.
        $fixture[] = 'Element';
 
        // Assert that the size of the Array fixture is 1.
        $this->assertEquals(1, sizeof($fixture));
    }
}
?>
